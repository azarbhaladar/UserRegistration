﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using UserRegistration.ViewModel;

namespace UserRegistration.Model
{
    public class DO_NOT_USED_UserInfoWithDataAnnotation : PropertyChangedNotification
    {
        public DO_NOT_USED_UserInfoWithDataAnnotation()
        {

        }

        [Required(ErrorMessage = "First Name is required")]
        public string FirstName
        {
            get { return GetValue(() => FirstName); }
            set { SetValue(() => FirstName, value); }
        }

        [Required(ErrorMessage = "Last Name is required")]
        public string LastName
        {
            get { return GetValue(() => LastName); }
            set { SetValue(() => LastName, value); }
        }

        [XmlIgnore]
        public int Id
        {
            get { return GetValue(() => Id); }
            set { SetValue(() => Id, value); }
        }

        [Required(ErrorMessage = "Email address is required")]
        [EmailAddress(ErrorMessage = "Email Address is Invalid")]
        public string Email
        {
            get { return GetValue(() => Email); }
            set { SetValue(() => Email, value); }
        }

        [Required(ErrorMessage = "Phone Number is required")]
        [RegularExpression("^(?!0+$)(\\+\\d{1,3}[- ]?)?(?!0+$)\\d{10,15}$", ErrorMessage = "Please enter valid phone no.")]
        public string PhoneNumber
        {
            get { return GetValue(() => PhoneNumber); }
            set { SetValue(() => PhoneNumber, value); }
        }

        //private int _id;
        //public int Id
        //{
        //    get
        //    {
        //        return _id;
        //    }
        //    set
        //    {
        //        _id = value;
        //        OnPropertyChanged("Id");
        //    }
        //}

        //private string _firstName;
        //public string FirstName
        //{
        //    get
        //    {
        //        return _firstName;
        //    }
        //    set
        //    {
        //        _firstName = value;
        //        OnPropertyChanged("FirstName");
        //    }
        //}

        //private string _lastName;
        //public string LastName
        //{
        //    get
        //    {
        //        return _lastName;
        //    }
        //    set
        //    {
        //        _lastName = value;
        //        OnPropertyChanged("LastName");
        //    }
        //}

        //private string _email;
        //public string Email
        //{
        //    get
        //    {
        //        return _email;
        //    }
        //    set
        //    {
        //        _email = value;
        //        OnPropertyChanged("Email");
        //    }
        //}

        //private string _address;
        //public string Address
        //{
        //    get
        //    {
        //        return _address;
        //    }
        //    set
        //    {
        //        _address = value;
        //        OnPropertyChanged("Address");
        //    }
        //}

        //private string _phoneNumber;
        //public string PhoneNumber
        //{
        //    get
        //    {
        //        return _phoneNumber;
        //    }
        //    set
        //    {
        //        _phoneNumber = value;
        //        OnPropertyChanged("PhoneNumber");
        //    }
        //}

        //private string _city;
        //public string City
        //{
        //    get
        //    {
        //        return _city;
        //    }
        //    set
        //    {
        //        _city = value;
        //        OnPropertyChanged("City");
        //    }
        //}

        //private string _state;
        //public string State
        //{
        //    get
        //    {
        //        return _state;
        //    }
        //    set
        //    {
        //        _state = value;
        //        OnPropertyChanged("State");
        //    }
        //}

        //private List<string> _stateList;
        //public List<string> StateList
        //{
        //    get
        //    {
        //        return _stateList;
        //    }
        //    set
        //    {
        //        _stateList = value;
        //        OnPropertyChanged("StateList");
        //    }
        //}

        //private string _zipCode;
        //public string ZipCode
        //{
        //    get
        //    {
        //        return _zipCode;
        //    }
        //    set
        //    {
        //        _zipCode = value;
        //        OnPropertyChanged("ZipCode");
        //    }
        //}

        //private DateTime _dateOfBirth;
        //public DateTime DateOfBirth
        //{
        //    get
        //    {
        //        return _dateOfBirth;
        //    }
        //    set
        //    {
        //        _dateOfBirth = value;
        //        OnPropertyChanged("DateOfBirth");
        //    }
        //}

        public ObservableCollection<UserInfoViewModel> UserRecords
        {
            get { return GetValue(() => UserRecords); }
            set { SetValue(() => UserRecords, value); }
        }

        public IList<UserInfoViewModel> UserRecordsfiltered
        {
            get { return GetValue(() => UserRecordsfiltered); }
            set { SetValue(() => UserRecordsfiltered, value); }
        }

        //private ObservableCollection<UserInfo> _userRecords;
        //public ObservableCollection<UserInfo> UserRecords
        //{
        //    get
        //    {
        //        return _userRecords;
        //    }
        //    set
        //    {
        //        _userRecords = value;
        //        OnPropertyChanged("UserRecords");
        //    }
        //}

        //private IList<UserInfo> _userRecordsfiltered;
        //public IList<UserInfo> UserRecordsfiltered
        //{
        //    get
        //    {
        //        return _userRecordsfiltered;
        //    }
        //    set
        //    {
        //        _userRecordsfiltered = value;
        //        OnPropertyChanged("UserRecordsfiltered");
        //    }
        //}

        //Dictionary<string, string> validationErrors = new Dictionary<string, string>();

        //#region IDataErrorInfo Members
        //public string Error
        //{
        //    get
        //    {
        //        if (validationErrors.Count > 0)
        //        {
        //            return "Errors found.";
        //        }
        //        return null;
        //    }
        //}
        //public string this[string columnName]
        //{
        //    get
        //    {
        //        GetAllValidationErrors();
        //        return validationErrors.ContainsKey(columnName) ? validationErrors[columnName] : string.Empty;
        //    }
        //}

        //#endregion

        //private void GetAllValidationErrors()
        //{
        //    validationErrors.Clear();
        //    if (String.IsNullOrEmpty(this.FirstName))
        //        validationErrors.Add(nameof(FirstName), "First Name needs to be entered.");
        //    if (this.FirstName.Trim().Length<5)
        //        validationErrors.Add(nameof(FirstName), "First Name should be minimum 5 characters.");
        //    if (String.IsNullOrEmpty(this.LastName))
        //        validationErrors.Add(nameof(LastName), "Last Name needs to be entered.");
        //}

    }
}
