﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;
using System.Windows.Input;
using UserRegistration.DBLayer;

namespace UserRegistration.ViewModel
{
    internal class MainViewModel : ViewModelBase
    {
        private ViewModelBase _selectedViewModel;
        private ICommand _userInfoCommand;

        #region Constructor
        public MainViewModel()
        {
            SelectedViewModel = new UserInfoViewModel();
        }

        #endregion

        public ViewModelBase SelectedViewModel
        {
            get
            {
                return _selectedViewModel;
            }
            set
            {
                _selectedViewModel = value;
                OnPropertyChanged("SelectedViewModel");
            }
        }

        public ICommand UserClickCommand
        {
            get
            {
                if (_userInfoCommand == null)
                    _userInfoCommand = new RelayCommand(param => SetVM((string)param), param => true);
                return _userInfoCommand;
            }
        }

        private void SetVM(string vmName)
        {
            if (vmName.Equals("UserInfo"))
                SelectedViewModel = new UserInfoViewModel();
            else if (vmName.Equals("UserDept"))
                SelectedViewModel = new UserDepartmentViewModel();
        }
    }
}
