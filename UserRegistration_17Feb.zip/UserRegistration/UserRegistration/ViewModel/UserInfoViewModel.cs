﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Input;
using UserRegistration.BusinessLayer;

namespace UserRegistration.ViewModel
{
    public class UserInfoViewModel : ViewModelBase, IDataErrorInfo
    {
        #region Private Properties
        private ICommand _saveCommand;
        private ICommand _resetCommand;
        private ICommand _editCommand;
        private ICommand _deleteCommand;
        private ICommand _populateDummyData;
        private BusinessLogic _businessLogic;
        #endregion

        #region Constructor
        public UserInfoViewModel()
        {
            _businessLogic = new BusinessLogic(this);
        }
        #endregion

        #region Commands

        public ICommand ResetCommand
        {
            get
            {
                if (_resetCommand == null)
                    _resetCommand = new RelayCommand(param => _businessLogic.ResetUserData(), null);

                return _resetCommand;
            }
        }

        public ICommand SaveCommand
        {
            get
            {
                if (_saveCommand == null)
                    _saveCommand = new RelayCommand(
                        param => SaveUser(),
                        param => IsOKtoSave());
                return _saveCommand;
            }
        }

        public ICommand EditCommand
        {
            get
            {
                if (_editCommand == null)
                    _editCommand = new RelayCommand(param => _businessLogic.SelectUserData((int)param), null);

                return _editCommand;
            }
        }

        public ICommand DeleteCommand
        {
            get
            {
                if (_deleteCommand == null)
                    _deleteCommand = new RelayCommand(param => _businessLogic.DeleteUser((int)param), null);

                return _deleteCommand;
            }
        }

        public ICommand PopulateDummyDataCommand
        {
            get
            {
                if (_populateDummyData == null)
                    _populateDummyData = new RelayCommand(param => _businessLogic.PopulateDummyData(), null);

                return _populateDummyData;
            }
        }

        #endregion
        
        #region Properties 

        private string _filter;
        public string Filter
        {
            get
            {
                return _filter;
            }
            set
            {
                if (value != _filter)
                {
                    _filter = value;
                    _businessLogic.SearchData(Filter);
                    OnPropertyChanged("Filter");
                }
            }
        }

        private bool _canShowPopUp;
        public bool CanShowPopUp
        {
            get
            {
                return _canShowPopUp;
            }
            set
            {
                _canShowPopUp = value;
                OnPropertyChanged("CanShowPopUp");
            }
        }

        private int _id;
        public int Id
        {
            get
            {
                return _id;
            }
            set
            {
                _id = value;
                OnPropertyChanged("Id");
            }
        }

        private string _firstName;
        public string FirstName
        {
            get
            {
                return _firstName;
            }
            set
            {
                _firstName = value;
                OnPropertyChanged("FirstName");
            }
        }

        private string _lastName;
        public string LastName
        {
            get
            {
                return _lastName;
            }
            set
            {
                _lastName = value;
                OnPropertyChanged("LastName");
            }
        }

        private string _email;
        public string Email
        {
            get
            {
                return _email;
            }
            set
            {
                _email = value;
                OnPropertyChanged("Email");
            }
        }

        private string _address;
        public string Address
        {
            get
            {
                return _address;
            }
            set
            {
                _address = value;
                OnPropertyChanged("Address");
            }
        }

        private string _phoneNumber;
        public string PhoneNumber
        {
            get
            {
                return _phoneNumber;
            }
            set
            {
                _phoneNumber = value;
                OnPropertyChanged("PhoneNumber");
            }
        }

        private string _city;
        public string City
        {
            get
            {
                return _city;
            }
            set
            {
                _city = value;
                OnPropertyChanged("City");
            }
        }

        private string _state;
        public string State
        {
            get
            {
                return _state;
            }
            set
            {
                _state = value;
                OnPropertyChanged("State");
            }
        }

        private List<string> _stateList;
        public List<string> StateList
        {
            get
            {
                return _stateList;
            }
            set
            {
                _stateList = value;
                OnPropertyChanged("StateList");
            }
        }

        private string _zipCode;
        public string ZipCode
        {
            get
            {
                return _zipCode;
            }
            set
            {
                _zipCode = value;
                OnPropertyChanged("ZipCode");
            }
        }

        private DateTime _dateOfBirth;
        public DateTime DateOfBirth
        {
            get
            {
                if (_dateOfBirth == DateTime.MinValue)
                {
                    return DateTime.Now;
                }
                return _dateOfBirth;
            }
            set
            {
                _dateOfBirth = value;
                OnPropertyChanged("DateOfBirth");
            }
        }

        private ObservableCollection<UserInfoViewModel> _userRecords;
        public ObservableCollection<UserInfoViewModel> UserRecords
        {
            get
            {
                return _userRecords;
            }
            set
            {
                _userRecords = value;
                OnPropertyChanged("UserRecords");
            }
        }

        private IList<UserInfoViewModel> _userRecordsfiltered;
        public IList<UserInfoViewModel> UserRecordsfiltered
        {
            get
            {
                return _userRecordsfiltered;
            }
            set
            {
                _userRecordsfiltered = value;
                OnPropertyChanged("UserRecordsfiltered");
            }
        }
        #endregion

        #region IDataErrorInfo Members

        Dictionary<string, string> validationErrors = new Dictionary<string, string>();
        public string Error
        {
            get
            {
                if (validationErrors.Count > 0)
                {
                    return "Errors found.";
                }
                return null;
            }
        }
        public string this[string columnName]
        {
            get
            {
                GetAllValidationErrors();
                return validationErrors.ContainsKey(columnName) ? validationErrors[columnName] : string.Empty;
            }
        }

        #endregion

        #region Private Methods

        private void SaveUser()
        {
            _businessLogic.SaveUserData();
            Filter = string.Empty;
        }

        private void GetAllValidationErrors()
        {
            validationErrors.Clear();
            if (string.IsNullOrEmpty(FirstName))
                validationErrors.Add(nameof(FirstName), "First Name needs to be entered.");
            if (!string.IsNullOrEmpty(FirstName) && FirstName.Trim().Length < 5)
                validationErrors.Add(nameof(FirstName), "First Name should be minimum 5 characters.");
            if (string.IsNullOrEmpty(LastName))
                validationErrors.Add(nameof(LastName), "Last Name needs to be entered.");
            if (!string.IsNullOrEmpty(LastName) && LastName.Trim().Length < 5)
                validationErrors.Add(nameof(LastName), "Last Name should be minimum 5 characters.");
            if (string.IsNullOrEmpty(Email))
                validationErrors.Add(nameof(Email), "Email needs to be entered.");
            if (!string.IsNullOrEmpty(Email) && !IsValidEmail(Email))
                validationErrors.Add(nameof(Email), "Email needs to be valid one.");
            if (string.IsNullOrEmpty(PhoneNumber))
                validationErrors.Add(nameof(PhoneNumber), "Phone Number needs to be entered.");
            if (!string.IsNullOrEmpty(PhoneNumber) && !IsValidPhone(PhoneNumber))
                validationErrors.Add(nameof(PhoneNumber), "Phone Number needs to be valid one.");
            if (string.IsNullOrEmpty(Address))
                validationErrors.Add(nameof(Address), "Address needs to be entered.");
            if (string.IsNullOrEmpty(City))
                validationErrors.Add(nameof(City), "City needs to be entered.");
            if (string.IsNullOrEmpty(State))
                validationErrors.Add(nameof(State), "State needs to be entered.");
            if (string.IsNullOrEmpty(ZipCode))
                validationErrors.Add(nameof(ZipCode), "Zip Code needs to be entered.");
            if (!string.IsNullOrEmpty(ZipCode) && !IsValidZipCode(ZipCode))
                validationErrors.Add(nameof(ZipCode), "Zip Code needs to be valid one.");
        }

        private bool IsValidEmail(string inputEmail)
        {
            string strRegex = @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}" +
                  @"\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\" +
                  @".)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$";
            Regex re = new Regex(strRegex);
            if (re.IsMatch(inputEmail))
                return true;
            else
                return false;
        }

        private bool IsValidPhone(string inputPhone)
        {
            string strRegex = @"^(\+91[\-\s]?)?[0]?(91)?[789]\d{9}$";
            Regex re = new Regex(strRegex);
            if (re.IsMatch(inputPhone))
                return true;
            else
               return (false);
        }

        private bool IsValidZipCode(string inputZipCode)
        {
            string strRegex = @"^[0-9]{1,6}$";
            Regex re = new Regex(strRegex);
            if (re.IsMatch(inputZipCode))
                return true;
            else
                return (false);
        }

        public bool IsOKtoSave()
        {
            return validationErrors.Count() == 0;
        }

        #endregion
    }
}