﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using UserRegistration.DBLayer;
using UserRegistration.Model;
using UserRegistration.ViewModel;

namespace UserRegistration.BusinessLayer
{
    public class BusinessLogic
    {
        private UserInfoViewModel UserInfoRecord;
        private UserRepository Repository;
        public BusinessLogic(UserInfoViewModel _userInfoRecord)
        {
            UserInfoRecord = _userInfoRecord;
            Repository = new UserRepository();
            GetAllData();
        }
        public void PopulateDummyData()
        {
            int countValue = UserInfoRecord.UserRecords.Count();
            var random = new Random();

            UserInfoRecord.FirstName = "DummyFName" + countValue;
            UserInfoRecord.LastName = "DummyLName" + countValue;
            UserInfoRecord.Email = "DummyEmail" + countValue + "@gmail.com";
            UserInfoRecord.PhoneNumber = "77344" + random.Next(0, 9) + "6789";
            UserInfoRecord.Address = "DummyAddress" + countValue;
            UserInfoRecord.City = "DummyCity" + countValue;
            UserInfoRecord.State = UserInfoRecord.StateList[random.Next(0, 6)];
            UserInfoRecord.ZipCode = "41610" + random.Next(0, 9);
            UserInfoRecord.DateOfBirth = DateTime.Now;
        }
        public void ResetUserData()
        {
            UserInfoRecord.Id = 0;
            UserInfoRecord.FirstName = string.Empty;
            UserInfoRecord.LastName = string.Empty;
            UserInfoRecord.Email = string.Empty;
            UserInfoRecord.PhoneNumber = string.Empty;
            UserInfoRecord.Address = string.Empty;
            UserInfoRecord.City = string.Empty;
            UserInfoRecord.State = string.Empty;
            UserInfoRecord.ZipCode = string.Empty;
            UserInfoRecord.DateOfBirth = DateTime.Now;
        }

        public UserInfo FillUserEntity()
        {
            UserInfo _userEntity = new UserInfo();
            _userEntity.FirstName = UserInfoRecord.FirstName;
            _userEntity.LastName = UserInfoRecord.LastName;
            _userEntity.Email = UserInfoRecord.Email;
            _userEntity.PhoneNumber = UserInfoRecord.PhoneNumber;
            _userEntity.Address = UserInfoRecord.Address;
            _userEntity.City = UserInfoRecord.City;
            _userEntity.State = UserInfoRecord.State;
            _userEntity.ZipCode = UserInfoRecord.ZipCode;
            _userEntity.DateOfBirth = UserInfoRecord.DateOfBirth;
            return _userEntity;
        }

        public void SelectUserData(int id)
        {
            var _userEntity = Repository.Get(id);
            UserInfoRecord.Id = _userEntity.Id;
            UserInfoRecord.FirstName = _userEntity.FirstName;
            UserInfoRecord.LastName = _userEntity.LastName;
            UserInfoRecord.Email = _userEntity.Email;
            UserInfoRecord.PhoneNumber = _userEntity.PhoneNumber;
            UserInfoRecord.Address = _userEntity.Address;
            UserInfoRecord.City = _userEntity.City;
            UserInfoRecord.State = _userEntity.State;
            UserInfoRecord.ZipCode = _userEntity.ZipCode;
            UserInfoRecord.DateOfBirth = _userEntity.DateOfBirth;
        }

        public void SearchData(string _filter)
        {
            UserInfoRecord.UserRecordsfiltered = UserInfoRecord.UserRecords.Where(x =>
                       x.FirstName.Contains(_filter, StringComparison.OrdinalIgnoreCase) ||
                       x.LastName.Contains(_filter, StringComparison.OrdinalIgnoreCase) ||
                       x.Email.Contains(_filter, StringComparison.OrdinalIgnoreCase) ||
                       x.Address.Contains(_filter, StringComparison.OrdinalIgnoreCase) ||
                       x.City.Contains(_filter, StringComparison.OrdinalIgnoreCase) ||
                       x.PhoneNumber.Contains(_filter, StringComparison.OrdinalIgnoreCase) ||
                       x.State.Contains(_filter, StringComparison.OrdinalIgnoreCase) ||
                       x.ZipCode.Contains(_filter, StringComparison.OrdinalIgnoreCase) ||
                       x.DateOfBirth.Date.ToString().Contains(_filter, StringComparison.OrdinalIgnoreCase))
                        .ToList();
        }

        public void GetAllData()
        {
            UserInfoRecord.UserRecords = new ObservableCollection<UserInfoViewModel>();
            Repository.GetAllUsers().ForEach(data => UserInfoRecord.UserRecords.Add(new UserInfoViewModel()
            {
                Id = data.Id,
                FirstName = data.FirstName,
                LastName = data.LastName,
                Email = data.Email,
                PhoneNumber = data.PhoneNumber,
                Address = data.Address,
                City = data.City,
                State = data.State,
                ZipCode = data.ZipCode,
                DateOfBirth = data.DateOfBirth
            }));
            UserInfoRecord.UserRecordsfiltered = UserInfoRecord.UserRecords.ToList();
            UserInfoRecord.StateList = Repository.GetAllStates().ToList();
        }

        public void DeleteUser(int id)
        {
            if (MessageBox.Show("Confirm delete of this record?", "Student", MessageBoxButton.YesNo)
                == MessageBoxResult.Yes)
            {
                try
                {
                    Repository.RemoveUser(id);
                    if (UserInfoRecord.CanShowPopUp)
                        MessageBox.Show("Record successfully deleted.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error occured while saving. " + ex.InnerException);
                }
                finally
                {
                    GetAllData();
                    ResetUserData();
                }
            }
        }

        public void SaveUserData()
        {
            if (UserInfoRecord != null)
            {
                var _userEntity = FillUserEntity();

                try
                {
                    if (UserInfoRecord.Id <= 0)
                    {
                        Repository.AddUser(_userEntity);
                        if (UserInfoRecord.CanShowPopUp)
                            MessageBox.Show("New record successfully saved.");
                    }
                    else
                    {
                        _userEntity.Id = UserInfoRecord.Id;
                        Repository.UpdateUser(_userEntity);
                        if (UserInfoRecord.CanShowPopUp)
                            MessageBox.Show("Record successfully updated.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error occured while saving. " + ex.InnerException);
                }
                finally
                {
                    GetAllData();
                    ResetUserData();
                }
            }
        }
    }
}
