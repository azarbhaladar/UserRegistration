﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UserRegistration.Model;

namespace UserRegistration.DBLayer
{
    public interface IUserRepository
    {
        UserInfo Get(int id);

        List<UserInfo> GetAllUsers();

        List<string> GetAllStates();

        void AddUser(UserInfo user);

        void UpdateUser(UserInfo user);

        void RemoveUser(int id);
    }
}
