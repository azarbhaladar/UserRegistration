﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UserRegistration.Model;

namespace UserRegistration.DBLayer
{
    public class UserRepository: IUserRepository
    {
        private UserEntities userContext = null;
        public UserRepository()
        {
            userContext = new UserEntities();
        }

        public UserInfo Get(int id)
        {
            return userContext.GetUserById(id);
        }

        public List<UserInfo> GetAllUsers()
        {
            return userContext.GetAll().ToList();
        }

        public List<string> GetAllStates()
        {
            return userContext.GetStates();
        }

        public void AddUser(UserInfo user)
        {
            if (user != null)
            {
                userContext.AddUser(user);
            }
        }

        public void UpdateUser(UserInfo user)
        {
            if (user != null)
            {
                userContext.UpdateUser(user);
            }
        }

        public void RemoveUser(int id)
        {
            var user = Get(id);
            if (user != null)
            {
                userContext.RemoveUser(user);
            }
        }
    }
}
