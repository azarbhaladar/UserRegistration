﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UserRegistration.Model;

namespace UserRegistration.DBLayer
{
    public class UserEntities
    {
        private List<UserInfo> Users;
        private List<string> StatesList;

        public UserEntities()
        {
            Users = new List<UserInfo>();
            StatesList = new List<string>
            {
                "Maharashtra",
                "Karnataka",
                "Delhi",
                "Rajasthan",
                "UP",
                "Bihar",
                "Gujarat"
            };
        }

        public void AddUser(UserInfo student)
        {
            student.Id = Users.Count + 1;
            Users.Add(student);
        }

        public List<UserInfo> GetAll()
        {
            return Users;
        }

        public List<string> GetStates()
        {
            return StatesList;
        }

        public UserInfo GetUserById(int id)
        {
            if (Users != null)
            {
                return Users.Where(x => x.Id.Equals(id)).FirstOrDefault();
            }
            return null;
        }

        public bool RemoveUser(UserInfo _user)
        {
            if (Users != null)
            {
                var student = GetUserById(_user.Id);
                return Users.Remove(student);
            }
            return false;
        }

        public bool UpdateUser(UserInfo _user)
        {
            if (Users != null)
            {
                var user = GetUserById(_user.Id);
                user.FirstName = _user.FirstName;
                user.LastName = _user.LastName;
                user.Email = _user.Email;
                user.PhoneNumber = _user.PhoneNumber;
                user.Address = _user.Address;
                user.City = _user.City;
                user.State = _user.State;
                user.ZipCode = _user.ZipCode;
                user.DateOfBirth = _user.DateOfBirth;

                return true;
            }
            return false;
        }
    }
}
